﻿using System;
using System.Text.RegularExpressions;

namespace UserDefinedException
{
    public class MyInvalidException : Exception
    {
        public MyInvalidException(string message) : base(message)
        {
        }
    }

    class Program
    {
        static bool IsValidEmail(string str)
        {
            const String pattern =
            @"^([0-9a-zA-Z]" + 
            @"([\+\-_\.][0-9a-zA-Z]+)*" + 
            @")+" +
            @"@(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]*\.)+[a-zA-Z0-9]{2,17})$";

            return Regex.IsMatch(str, pattern);
        }

        static string CkeckEmail(out Exception eObj)
        {
            string addr;
            do
            {
                eObj = null;
                Console.WriteLine("Enter e-mail address: ");
                addr = Console.ReadLine();

                try
                {
                    if (!IsValidEmail(addr))
                    {
                        throw (new MyInvalidException("Invalid e-mail address!"));
                    }
                }
                catch (MyInvalidException e)
                {
                    Console.WriteLine("MyEmailException: {0}", e.Message);
                    eObj = e;
                }

            } while (eObj != null);

            return addr;
        }

        static bool IsValidName(string str)
        {
            if (string.IsNullOrEmpty(str))
                return false;

            string[] words = str.Split(' ');

            foreach (string word in words)
            {
                if (string.IsNullOrEmpty(word))
                    continue;

                if (!char.IsUpper(word[0]))
                    return false;

                if (word.Contains(".."))
                    return false;

                int dotIndex = word.IndexOf('.');
                if (dotIndex >= 0 && dotIndex < word.Length - 1)
                    return false;

                foreach (char c in word)
                {
                    if (!char.IsLetter(c) && c != '.')
                        return false;
                }

                for (int i = 1; i < word.Length; i++)
                {
                    if (word[i] != '.' && char.IsUpper(word[i]))
                        return false;
                }
            }

            // Check for proper spacing after dots
            string[] dotsplit = str.Split('.');
            for (int i = 0; i < dotsplit.Length - 1; i++)
            {
                // If the dot is not at the end of the string
                if (i < dotsplit.Length - 1)
                {
                    // Check if the character after dot is a space
                    int dotPos = dotsplit[i].Length + i;
                    if (dotPos + 1 < str.Length && str[dotPos + 1] != ' ')
                        return false;
                }
            }

            // Check if the first character is not a dot
            if (str[0] == '.')
                return false;

            return true;
        }

        static string CkeckName(out Exception eObj)
        {
            string name;
            do
            {
                eObj = null;
                Console.WriteLine("Enter name: ");
                name = Console.ReadLine();

                try
                {
                    if (!IsValidName(name))
                    {
                        throw (new MyInvalidException("Invalid Name! \nName must start with a Capital letter and no digits or symbols are allowed except dot(.)"));
                    }
                }
                catch (MyInvalidException e)
                {
                    Console.WriteLine("MyNameException: {0}", e.Message);
                    eObj = e;
                }

            } while (eObj != null);

            return name;
        }

        static bool IsValidPhone(string str)
        {
            if (string.IsNullOrEmpty(str))
                return false;

            string pattern = @"^(\+)?(\d{1,4})?[\s\-]?(\d{3})[\s\-](\d{3})[\s\-](\d{4})$";

            if (!Regex.IsMatch(str, pattern))
                return false;

            // Additional checks
            // Check for double + signs
            if (str.Contains("++"))
                return false;

            if (str[0] != '+' && str[0] != '0' && str[0] != '1' && str[0] != '2' && str[0] != '3' &&
                str[0] != '4' && str[0] != '5' && str[0] != '6' && str[0] != '7' && str[0] != '8' && str[0] != '9')
                return false;

            if (str.StartsWith("+"))
            {
                int codeEndIndex = str.IndexOfAny(new char[] { ' ', '-' });
                if (codeEndIndex > 5)
                    return false;
            }

            int digitCount = 0;
            foreach (char c in str)
            {
                if (char.IsDigit(c))
                    digitCount++;
            }

            if (digitCount < 10)
                return false;

            return true;
        }

        static string CkeckPhone(out Exception eObj)
        {
            string phone;
            do
            {
                eObj = null;
                Console.WriteLine("Enter phone number: ");
                phone = Console.ReadLine();

                try
                {
                    if (!IsValidPhone(phone))
                    {
                        throw (new MyInvalidException("Invalid Phone Number!\nAccepted Format: +(1 to 4 digits internal code (optional)) - (3 digits) - (3 digits)-(4 digits)"));
                    }
                }
                catch (MyInvalidException e)
                {
                    Console.WriteLine("MyPhoneException: {0}", e.Message);
                    eObj = e;
                }

            } while (eObj != null);

            return phone;
        }

        static void Main(string[] args)
        {
            Exception eObj;
            string Name = CkeckName(out eObj);
            string Phone = CkeckPhone(out eObj);
            string Email = CkeckEmail(out eObj);

            Console.WriteLine();
            Console.WriteLine("Your Name is : " + Name);
            Console.WriteLine("Your Phone Number is : " + Phone);
            Console.WriteLine("Your e-mail is : " + Email); 

            Console.ReadLine();
        }
    }
}
